#ifndef __SBT_DEFINE_H__
#define __SBT_DEFINE_H__
#include "ast.h"
#include "info.h"

extern int line_no, col_no, yyleng;

struct SymbolTable_Element
{
  string name;
  int scope;
  string type;
  string K_Type;
  bool bDecl=false;
};

class MySymbolTable
{
public:
   unordered_map<string,SymbolTable_Element> symbolMap;
   

   //Add something to symboltalbe
   bool addSymbol(const string &key,const SymbolTable_Element &value)
   {
   	auto it = symbolMap.find(key);
   	string tmpk=key;
   	//the key already include
   	if(it!=symbolMap.end())
      {
   	   if(it->second.K_Type =="variable")
         {
            fprintf(stderr,REDEF_VAR,line_no, col_no - yyleng,tmpk.c_str());
         }
         else if(it->second.type =="FUNCTION")
         {
            fprintf(stderr,REDEF_FUN,line_no, col_no - yyleng,tmpk.c_str());
         }
         else if(it->second.type =="PARA")
         {
         
         }
         return false;
   	}
      else
      {
         symbolMap[key]=value;
        // SHOW_NEWSYM(value.name);
        return true;
      }
   }

   //find something from symboltable
   SymbolTable_Element findSymbol(const string &key)
   {
      auto it = symbolMap.find(key);
      if(it !=symbolMap.end())
      {
         return it->second;
      }
      else
      {
         cout<<"Key not found"<<endl;
         return SymbolTable_Element();
      }
   }

   //remove something from symboltable
   void removeElementsByScope(int targetScope)
   {
      for(auto it = symbolMap.begin();it!=symbolMap.end();)
      {
         if(it->second.scope == targetScope)
         {
            it = symbolMap.erase(it);
         }
         else
         {
            ++it;
         }
      }
   }

   void clear()
   {
      symbolMap.clear();
   }
};

//static vector<MySymbolTable> symbolTable_K;
static MySymbolTable symbolTable_Q;
#endif
