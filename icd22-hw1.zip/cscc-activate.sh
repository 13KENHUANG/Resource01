dosh run plaslab/compiler-f20-hw1:latest /bin/bash
