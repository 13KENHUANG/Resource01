#ifndef __AST_H__
#define __AST_H__


#ifdef __cplusplus
#include <iostream>
#include <string>
#include <vector>
#include <bitset>
#include <list>
#include <unordered_map>
#endif


#include "loc.h"
#include <stdint.h>
#include "typemap.h"




/* It's just for reference,
 * you can design your own
 * struct or class to impl inheritance in c/cpp */
 
using namespace std;

/*1-10*/
enum DeclarationKind {
	ROUTINEHEAD = 1,
	FUNCTION_Tree,
	FUNCTIONHEAD,
	PROCEDURE_Tree,
	PROCEDUREHEAD,
	DK_CONST,
	VAR_Tree,
	TYPE,
	VAR_PARA,
	VAL_PARA
};

/*11-16*/
enum ExpressionKind {
    EK_ID = 11,
    EK_CONST,
    OP,
    EK_CASE,
    FUNC_ID,
    FUNC_SYS
};

/*17-26*/
enum ExpressionType {
    VOID = 17,
    INT,
    REAL_Tree,
    CHAR,
    STRING_Tree,
    BOOL_Tree,
    ET_ARRAY,
    ET_RECORD,
    ET_SIMPLE_ENUM,
    ET_SIMPLE_LIMIT
};
/*27-56*/
enum OperationKind {
    TO = 27,
    DOWNTO,
    READ,
    WRITE,
    WRITELN,
    PLUS,
    MINUS,
    MUL,
    DIV,
    MOD,
    LT,
    LE,
    GT,
    GE,
    EQUAL,
    UNEQUAL, 
    NOT_Tree, 
    OR_Tree, 
    AND_Tree, 
    CHR, 
    ABS, 
    ODD, 
    ORD, 
    SQRT, 
    SUCC, 
    PRED, 
    SQR, 
    OK_ID, 
    OK_RECORD, 
    OK_ARRAY
};

/*57-67*/
enum StatementKind {
    LABEL = 57,
    ASSIGN,
    GOTO,
    IF_Tree,
    REPEAT,
    WHILE_Tree,
    FOR,
    SK_CASE,
    PROC_ID,
    PROC_SYS
};

/*67-72*/
enum TypeKind {
    SIMPLE_SYS = 67,
    SIMPLE_ID,
    TK_SIMPLE_ENUM,
    TK_SIMPLE_LIMIT,
    TK_ARRAY,
    TK_RECORD
};

typedef class TreeDefine *TreeNode;

/* define in symboldefine.h*/
class RecordDefinition;
class SubBoundDefinition;
class ArrayDefinition;



//-----symbol table-------//
struct SymbolTable_element{
   int scope=0;
   string type="void";
   bool redef=false;
   int upper_bound=0;
   int lower_bound=0;
   vector<string>para;
};


/*
         unordered_map<std::string, SymbolTable_element> global_SBT;
         mySBT.push_back(global_SBT);
         if(mySBT[0].find(key)!=mySBT[0].end()) //global_SBT already has the key 
	{
	             
	}
         else
	{
	  SHOW_NEWSYM($2);
	}*/




struct Object
{
    int flag;
    int _int;
    double _double;
    string _string;

    RecordDefinition* rd;//5 enum
    list<struct Object> lo;//6 record
    SubBoundDefinition* sd;//7 array index
    ArrayDefinition* ad;//8 array
};

class TreeDefine
{
    private:
    vector<TreeNode> childNode;
    TreeNode siblingNode = NULL;
    int nodeType = 0;//init value
    Object attribute;
    ExpressionType expressionType;
    ExpressionType runtimeType;
    int lineNumber = 0;
    int columnNumber = 0;
    bitset<32> bitSet;

    public:
    TreeDefine() {}

    TreeDefine(ExpressionKind nodeType, int lineNumber):nodeType(nodeType),lineNumber(lineNumber){ this->expressionType = VOID;}

    TreeDefine(DeclarationKind nodeType, int lineNumber):nodeType(nodeType),lineNumber(lineNumber) {}

    TreeDefine(TypeKind nodeType, int lineNumber):nodeType(nodeType),lineNumber(lineNumber) {}

    TreeDefine(StatementKind nodeType, int lineNumber):nodeType(nodeType),lineNumber(lineNumber) {}

    TreeDefine(TreeNode first, TreeNode second, OperationKind op, int lineNumber) {
  		this->nodeType = OP;
		this->attribute._int = op;
		this->attribute.flag = 4;//expression type
		this->lineNumber = lineNumber;
		this->addChild(first);
		this->addChild(second);
    }

    TreeDefine(OperationKind op, TreeNode child, int lineNumber) {
        this->nodeType = FUNC_SYS;
        this->attribute._int = op;
        this->attribute.flag = 4;//type
        this->lineNumber = lineNumber;
        this->addChild(child);
    }

    vector<TreeNode> getChildren();
    void addChild(TreeNode node);

    TreeNode getSibling();
    void setSibling(TreeNode siblingNode);

    int getLineNumber();
    void setLineNumber(int lineNumber);

    int getNodeType();
    void setNodeType(int nodeType);

    Object getAttribute();
    void setAttribute(Object attribute);
    void setAttribute(int attribute,int flag);
    void setAttribute(double attribute);
    void setAttribute(string attribute);

    ExpressionType getExpType();
    void setExpType(ExpressionType expressionType);

    ExpressionType getRunTimeType();
    void setRunTimeType(ExpressionType runtimeType);

    void printTree(TreeNode root, int level);
    
    void print_K(TreeNode root,int level);
};


typedef enum{ ProgNode, /* types */ } NodeType;

typedef struct NodeTag{
  NodeType nt;
  LocType  loc;
  /* some fields */
} *Node, NodeStr;

#define Obj void*

typedef struct ConsTag{
  Obj car;
  struct ConsTag *cdr;
} *Cons, ConsStr;

#endif
