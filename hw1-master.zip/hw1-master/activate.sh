docker run --rm -it -w /root -v "${PWD}":/root/hw1 plaslab/compiler-f20-hw1:latest /bin/bash
