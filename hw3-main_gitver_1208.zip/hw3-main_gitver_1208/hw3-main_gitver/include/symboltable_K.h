#ifndef SYMBOLTABLE_K_H
#define SYMBOLTABLE_K_H

#include "ast.h"


struct SymbolTableEntry{


};



#endif
