#ifndef __AST_H__
#define __AST_H__


#ifdef __cplusplus
#include <iostream>
#include <string>
#include <vector>
#include <bitset>
#include <list>
#include <sstream>
#include <iomanip>
#include <unordered_map>
#endif


#include "loc.h"
#include <stdint.h>
#include "typemap.h"
#include "sbt _define.h"



/* It's just for reference,
 * you can design your own
 * struct or class to impl inheritance in c/cpp */
 
using namespace std;

/*1-10*/
enum DeclarationKind {
	ROUTINEHEAD = 1,
	FUNCTION_Tree,
	FUNCTIONHEAD,
	PROCEDURE_Tree,
	PROCEDUREHEAD,
	DK_CONST,
	VAR_Tree,
	TYPE,
	VAR_PARA,
	VAL_PARA
};

/*11-16*/
enum ExpressionKind {
    EK_ID = 11,
    EK_CONST,
    OP,
    EK_CASE,
    FUNC_ID,
    FUNC_SYS
};

/*17-26*/
enum ExpressionType {
    VOID = 17,
    INT,
    REAL_Tree,
    CHAR,
    STRING_Tree,
    BOOL_Tree,
    ET_ARRAY,
    ET_RECORD,
    ET_SIMPLE_ENUM,
    ET_SIMPLE_LIMIT
};
/*27-56*/
enum OperationKind {
    TO = 27,
    DOWNTO,
    READ,
    WRITE,
    WRITELN,
    PLUS,
    MINUS,
    MUL,
    DIV,
    MOD,
    LT,
    LE,
    GT,
    GE,
    EQUAL,
    UNEQUAL, 
    NOT_Tree, 
    OR_Tree, 
    AND_Tree, 
    CHR, 
    ABS, 
    ODD, 
    ORD, 
    SQRT, 
    SUCC, 
    PRED, 
    SQR, 
    OK_ID, 
    OK_RECORD, 
    OK_ARRAY
};

/*57-67*/
enum StatementKind {
    LABEL = 57,
    ASSIGN,
    GOTO,
    IF_Tree,
    REPEAT,
    WHILE_Tree,
    FOR,
    SK_CASE,
    PROC_ID,
    PROC_FUNC
};

/*67-72*/
enum TypeKind {
    SIMPLE_SYS = 67,
    SIMPLE_ID,
    TK_SIMPLE_ENUM,
    TK_SIMPLE_LIMIT,
    TK_ARRAY,
    TK_RECORD
};

typedef class TreeDefine *TreeNode;

//-----symbol table-------//



struct Object
{
    int flag;
    int _int;
    double _double;
    string _string;

    list<struct Object> lo;//6 record
};



class TreeDefine
{
    private:
    vector<TreeNode> childNode;
    TreeNode siblingNode = NULL;
    int nodeType = 0;//init value
    Object attribute;
    ExpressionType expressionType;
    ExpressionType runtimeType;
    int lineNumber = 0;
    int columnNumber = 0;
    bitset<32> bitSet;

    public:
    TreeDefine() {}

    TreeDefine(ExpressionKind nodeType, int lineNumber,int col):nodeType(nodeType),lineNumber(lineNumber),columnNumber(col){ this->expressionType = VOID;}

    TreeDefine(DeclarationKind nodeType, int lineNumber,int col):nodeType(nodeType),lineNumber(lineNumber),columnNumber(col) {}

    TreeDefine(TypeKind nodeType, int lineNumber,int col):nodeType(nodeType),lineNumber(lineNumber),columnNumber(col) {}

    TreeDefine(StatementKind nodeType, int lineNumber,int col):nodeType(nodeType),lineNumber(lineNumber),columnNumber(col) {}

    TreeDefine(TreeNode first, TreeNode second, OperationKind op, int lineNumber,int col) {
  		this->nodeType = OP;
		this->attribute._int = op;
		this->attribute.flag = 4;//expression type
		this->lineNumber = lineNumber;
		this->columnNumber = col;
		this->addChild(first);
		this->addChild(second);
    }

    TreeDefine(OperationKind op, TreeNode child, int lineNumber,int col) {
        this->nodeType = FUNC_SYS;
        this->attribute._int = op;
        this->attribute.flag = 4;//type
        this->lineNumber = lineNumber;
        this->columnNumber = col;
        this->addChild(child);
    }

    vector<TreeNode> getChildren();
    void addChild(TreeNode node);

    TreeNode getSibling();
    void setSibling(TreeNode siblingNode);

    int getLineNumber();
    void setLineNumber(int lineNumber);
    
    int getColNumber();
    void setColNumber(int colNumber);

    int getNodeType();
    void setNodeType(int nodeType);

    Object getAttribute();
    void setAttribute(Object attribute);
    void setAttribute(int attribute,int flag);
    void setAttribute(double attribute);
    void setAttribute(string attribute);

    ExpressionType getExpType();
    void setExpType(ExpressionType expressionType);

    ExpressionType getRunTimeType();
    void setRunTimeType(ExpressionType runtimeType);

    void printTree(TreeNode root, int level);
    
    void print_K(TreeNode root,int level);
    
    void Print_Test(TreeNode root);
    
    //----Main Function----
    void theCreate(TreeNode root);  

    void Sub_Var_decl(MySymbolTable &subTable,TreeNode root,int ,vector<string> &subShow);
    
    void FunPro_decl(MySymbolTable &symbolTable_Q,TreeNode root,int );
    
    void Label_handle(MySymbolTable &myTable,TreeNode root,string re_func="",bool suc_defunc=true,int row=0,int col=0);

    void Label_Declared_Check(MySymbolTable &myTable,TreeNode root,bool &check,string re_func="",bool suc_defunc=true,int row=0,int col=0);

    void Label_handle_ASSIGN(MySymbolTable &myTable,TreeNode root);

    void Label_check_OP(MySymbolTable &myTable,TreeNode root,vector<string> type);

    vector<string> Spilt_type(string type);

};


typedef enum{ ProgNode, /* types */ } NodeType;

typedef struct NodeTag{
  NodeType nt;
  LocType  loc;
  /* some fields */
} *Node, NodeStr;

#define Obj void*

typedef struct ConsTag{
  Obj car;
  struct ConsTag *cdr;
} *Cons, ConsStr;

#endif
