# ICD20 Homework4 Example

About the IO, we will run the [io.class](./external_io/io.j) with the test case,
so you can call the function in in class, please refer the Jasmin code in `external_io`.

Both of the code in `external_io` and `builtins_io` are allowed.
